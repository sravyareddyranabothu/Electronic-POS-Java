package electronicspos.db;

public class DBTest {
    public static void main(String[] args) {
        DBConnection.getConnection();
    }
}
